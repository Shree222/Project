package com.pack.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.model.User;
import com.pack.model1.Customer;
import com.pack.service.UserService;


@Controller
public class UserController {
	
	@Autowired
	private UserService userService;

	@RequestMapping("tolog")
	public String log(Model m)
	{
		
		m.addAttribute("userBean", new User());
		return "login";
	}
	/*
	@RequestMapping(value="/dolog",method=RequestMethod.POST)
	public String loguser(@Valid @ModelAttribute("userBean")User userBean,BindingResult result,Model m)
	{
		if (result.hasErrors())
		{
			System.out.println("without submit");
		  return "login";
		 }
		else {
			//m.addAttribute("user",userBean);
			
			System.out.println("going to service");
			User user1=userService.logUser(userBean);
	  		if(user1 != null)
	  		{
	  			return "welcome";	
	  		}
	  		else
	  			return "login";
	  		
		}
		
	}*/
	
	@RequestMapping(value="/dolog",method=RequestMethod.POST)
	public String loguser(@Valid @ModelAttribute("userBean")User userBean,BindingResult result,Model m)
	{
		if (result.hasErrors())
		{
			System.out.println("without submit");
		  return "login";
		 }
		else 
		{
			System.out.println("going to service");
			userService.logUser(userBean);
			return "success";

		}
		
		
		
	}
	
	
	
	
	
	@RequestMapping("tocreate")
	public String create(Model m)
	{
		
		m.addAttribute("user", new Customer());
		return "create";
	}
	@RequestMapping(value="/doAdd", method = RequestMethod.POST)
	public String addUser(@Valid @ModelAttribute("user")Customer user,BindingResult result,Model m)
	{
		System.out.println("into doAdd mtd");
		 if (result.hasErrors())
			 {
	
			  return "create";
			 }
	 else
	 {
		
		 System.out.println("going to service");
 		userService.addUser(user); 
 		 return "final";
		
		
	}
	}
	
	
}
