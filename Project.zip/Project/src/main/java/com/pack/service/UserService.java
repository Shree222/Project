package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.UserDao;
import com.pack.model.User;
import com.pack.model1.Customer;



public class UserService {
	@Autowired
	private UserDao userDAO;

	
	/*public User logUser(User userBean) {
		System.out.println("into service");
		
		User user1=userDAO.logUser(userBean);
		return user1;
	}
	*/
	public void logUser(User userBean) {
		System.out.println("into service");
		
		userDAO.logUser(userBean);
	}


	public void addUser(Customer user) {
		System.out.println("into service");
		userDAO.addUser(user);
		
	}
		
}
