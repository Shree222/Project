package com.pack.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.model.User;
import com.pack.model1.Customer;

public class UserDao {

	@Autowired
	private	 SessionFactory sessionFactory;
	 
	
	public  String logUser(User userBean) {
		System.out.println("into dao");
		User user1=null;
		 Session session=sessionFactory.openSession();
		  
		  String hql="from LoginTable1 as s where s.username=:uname and u.password=:pwd";
		  Query query = session.createQuery(hql);
		  query.setParameter("uname", userBean.getUname());
		  query.setParameter("pwd", userBean.getPwd());
		  List<User> list=query.getResultList();
		if( list.size()==0)
		{
			return "login";
		}
		else
			return "welcome";
		
		
		
		/*public  User logUser(User userBean) {
			System.out.println("into dao");
			User user1=null;
			 Session session=sessionFactory.openSession();
			  
			  String hql="select s.username and s.password from LoginTable1 s";
			  Query query = session.createQuery(hql);
			  List<User> list=query.getResultList();
		  	 
		  	 for (User u:list)
		  	 {
		  		 user1=u; 
		  	 }
		  	System.out.println(user1);
		  	 return user1;
		  	 */
		  	 
		  
		 
	}


	public void addUser(Customer user) {
			System.out.println("into dao methd");
			   
			 Session session=sessionFactory.openSession();
			  Transaction tx=session.beginTransaction();
			  session.save(user);
			  tx.commit();
			  session.close(); 
		  
		
	}

	

}
